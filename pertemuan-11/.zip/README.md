# pertemuan-11

NIM : 2511500006<br>
NAMA : Grezelco Govin<br>
Hari ini, Rabu 03.Des.2025, saya mempelajari:<br>
<ol>
   <li>fungsi.php untuk helper redirect sederhana (pola PRG)</li>
   <li>menggunakan method=post dan action=proses.php</li>
   <li>menambahkan penangkap pesan sukses/gagal</li>
   <li>menampilan flash message</li>
   <li>menampilkan nilai lama dari form untuk antisipasi jika ada eror</li>
   <li>REQUEST_METHOD apakah menggunakan 'POST'</li>
   <li>ambil data $_POST, trim, htmlspecialchars</li>
   <li>mengisi bagian validasi</li>
   <li>menambahkan kolom nomor urut (bukan ID) pada read.php di kolom pertama</li>
</ol>